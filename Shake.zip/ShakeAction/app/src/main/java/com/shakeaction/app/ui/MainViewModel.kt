package com.shakeaction.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shakeaction.app.data.AutomationDatabase
import com.shakeaction.app.data.AutomationEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val dao =
        AutomationDatabase
            .get(application)
            .automationDao()

    val automations: StateFlow<List<AutomationEntity>> =
        dao.observeAll().stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(
                stopTimeoutMillis = 5_000L
            ),
            initialValue = emptyList()
        )

    fun addDefaultAutomation() {
        viewModelScope.launch {
            dao.insert(
                AutomationEntity(
                    name = "Shake twice",
                    gesture = "DOUBLE_SHAKE",
                    action = "TOGGLE_FLASHLIGHT",
                    sensitivity = 2.7f,
                    cooldownMs = 1_000L,
                    vibrationEnabled = true
                )
            )
        }
    }

    fun addStrongShakeAutomation() {
        viewModelScope.launch {
            dao.insert(
                AutomationEntity(
                    name = "Strong shake",
                    gesture = "STRONG_SHAKE",
                    action = "VIBRATE"
                )
            )
        }
    }

    fun delete(rule: AutomationEntity) {
        viewModelScope.launch {
            dao.delete(rule)
        }
    }

    fun setEnabled(
        rule: AutomationEntity,
        enabled: Boolean
    ) {
        viewModelScope.launch {
            dao.setEnabled(
                id = rule.id,
                enabled = enabled
            )
        }
    }
}