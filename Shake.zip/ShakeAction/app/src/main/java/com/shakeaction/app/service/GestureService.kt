package com.shakeaction.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.shakeaction.app.MainActivity
import com.shakeaction.app.R
import com.shakeaction.app.actions.ActionExecutor
import com.shakeaction.app.data.AutomationDatabase
import com.shakeaction.app.data.AutomationEntity
import com.shakeaction.app.detector.GestureDetector
import com.shakeaction.app.detector.GestureType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class GestureService :
    Service(),
    SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var gestureDetector: GestureDetector
    private lateinit var actionExecutor: ActionExecutor

    private val serviceScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var rulesJob: Job? = null

    @Volatile
    private var rules: List<AutomationEntity> = emptyList()

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()

        startForeground(
            NOTIFICATION_ID,
            createNotification()
        )

        sensorManager =
            getSystemService(SENSOR_SERVICE) as SensorManager

        actionExecutor = ActionExecutor(applicationContext)

        gestureDetector = GestureDetector(
            sensitivity = DEFAULT_SENSITIVITY,
            cooldownMs = DEFAULT_COOLDOWN_MS
        ) { gesture ->
            serviceScope.launch {
                executeMatchingRules(gesture)
            }
        }

        registerAccelerometer()
        observeRules()
    }

    private fun registerAccelerometer() {
        val accelerometer = sensorManager.getDefaultSensor(
            Sensor.TYPE_ACCELEROMETER
        )

        if (accelerometer == null) {
            stopSelf()
            return
        }

        sensorManager.registerListener(
            this,
            accelerometer,
            SensorManager.SENSOR_DELAY_GAME
        )
    }

    private fun observeRules() {
        rulesJob = serviceScope.launch {
            AutomationDatabase
                .get(applicationContext)
                .automationDao()
                .observeAll()
                .collectLatest { latestRules ->
                    rules = latestRules
                }
        }
    }

    private suspend fun executeMatchingRules(
        gesture: GestureType
    ) {
        val gestureName = gesture.name

        rules
            .filter { rule ->
                rule.enabled &&
                    rule.gesture == gestureName
            }
            .forEach { rule ->
                actionExecutor.execute(rule)
            }
    }

    override fun onSensorChanged(
        event: SensorEvent
    ) {
        gestureDetector.onSensorChanged(event)
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) {
        // No action needed.
    }

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_START,
            null -> {
                // Service is already initialized in onCreate().
            }
        }

        return START_STICKY
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        rulesJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(
        intent: Intent?
    ): IBinder? {
        return null
    }

    private fun createNotification(): Notification {
        val openAppIntent = Intent(
            this,
            MainActivity::class.java
        )

        val openAppPendingIntent =
            PendingIntent.getActivity(
                this,
                REQUEST_OPEN_APP,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    PendingIntent.FLAG_IMMUTABLE
            )

        val stopIntent = Intent(
            this,
            GestureService::class.java
        ).apply {
            action = ACTION_STOP
        }

        val stopPendingIntent =
            PendingIntent.getService(
                this,
                REQUEST_STOP_SERVICE,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or
                    PendingIntent.FLAG_IMMUTABLE
            )

        return NotificationCompat.Builder(
            this,
            CHANNEL_ID
        )
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("ShakeAction is active")
            .setContentText(
                "Listening for your configured gestures"
            )
            .setContentIntent(openAppPendingIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop",
                stopPendingIntent
            )
            .setOngoing(true)
            .setAutoCancel(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return
        }

        val channel = NotificationChannel(
            CHANNEL_ID,
            "Gesture detection",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description =
                "Shows when ShakeAction is monitoring gestures"
        }

        val manager =
            getSystemService(NotificationManager::class.java)

        manager?.createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID =
            "shakeaction_gesture_detection"

        private const val NOTIFICATION_ID = 1001

        private const val REQUEST_OPEN_APP = 1002
        private const val REQUEST_STOP_SERVICE = 1003

        private const val DEFAULT_SENSITIVITY = 2.7f
        private const val DEFAULT_COOLDOWN_MS = 1_000L

        const val ACTION_START =
            "com.shakeaction.app.action.START_SERVICE"

        const val ACTION_STOP =
            "com.shakeaction.app.action.STOP_SERVICE"
    }
}