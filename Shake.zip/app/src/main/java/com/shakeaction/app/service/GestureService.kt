package com.shakeaction.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.shakeaction.app.MainActivity
import com.shakeaction.app.R
import com.shakeaction.app.actions.ActionExecutor
import com.shakeaction.app.data.AutomationDatabase
import com.shakeaction.app.data.AutomationEntity
import com.shakeaction.app.detector.GestureDetector
import com.shakeaction.app.detector.GestureType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class GestureService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var detector: GestureDetector
    private lateinit var actionExecutor: ActionExecutor

    private val serviceScope =
        CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var rulesJob: Job? = null
    private var rules: List<AutomationEntity> = emptyList()

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        startForeground(
            NOTIFICATION_ID,
            buildNotification()
        )

        sensorManager =
            getSystemService(SENSOR_SERVICE) as SensorManager

        actionExecutor = ActionExecutor(applicationContext)

        detector = GestureDetector(
            sensitivity = DEFAULT_SENSITIVITY,
            cooldownMs = DEFAULT_COOLDOWN_MS
        ) { gesture ->
            serviceScope.launch {
                handleGesture(gesture)
            }
        }

        val accelerometer =
            sensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER
            )

        if (accelerometer != null) {
            sensorManager.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_GAME
            )
        }

        rulesJob = serviceScope.launch {
            rules = AutomationDatabase
                .get(applicationContext)
                .automationDao()
                .observeAll()
                .first()
        }
    }

    private suspend fun handleGesture(
        gesture: GestureType
    ) {
        val gestureName = gesture.name

        rules
            .filter { rule ->
                rule.enabled && rule.gesture == gestureName
            }
            .forEach { rule ->
                actionExecutor.execute(rule)
            }
    }

    override fun onSensorChanged(event: SensorEvent) {
        detector.onSensorChanged(event)
    }

    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) = Unit

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        rulesJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private fun buildNotification(): Notification {
        val launchIntent = Intent(
            this,
            MainActivity::class.java
        )

        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(
            this,
            CHANNEL_ID
        )
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("ShakeAction is active")
            .setContentText("Listening for configured gestures")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return
        }

        val channel = NotificationChannel(
            CHANNEL_ID,
            "Gesture detection",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description =
                "Shows when ShakeAction is monitoring gestures"
        }

        getSystemService(NotificationManager::class.java)
            ?.createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID = "gesture_detection"
        private const val NOTIFICATION_ID = 1001

        private const val DEFAULT_SENSITIVITY = 2.7f
        private const val DEFAULT_COOLDOWN_MS = 1_000L

        const val ACTION_START =
            "com.shakeaction.app.START_SERVICE"

        const val ACTION_STOP =
            "com.shakeaction.app.STOP_SERVICE"
    }
}