package com.shakeaction.app.detector

import android.hardware.Sensor
import android.hardware.SensorEvent
import kotlin.math.sqrt

class GestureDetector(
    private val sensitivity: Float = 2.7f,
    private val cooldownMs: Long = 1_000L,
    private val onGesture: (GestureType) -> Unit
) {
    private val gravity = FloatArray(3)
    private val peakTimes = ArrayDeque<Long>()

    private var lastPeakTime = 0L
    private var lastGestureTime = 0L
    private var continuousStartTime = 0L

    fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) {
            return
        }

        val alpha = 0.8f

        for (index in 0..2) {
            gravity[index] =
                alpha * gravity[index] +
                    (1f - alpha) * event.values[index]
        }

        val linearX = event.values[0] - gravity[0]
        val linearY = event.values[1] - gravity[1]
        val linearZ = event.values[2] - gravity[2]

        val magnitude = sqrt(
            linearX * linearX +
                linearY * linearY +
                linearZ * linearZ
        )

        val now = event.timestamp / 1_000_000L

        if (magnitude < sensitivity) {
            if (
                continuousStartTime != 0L &&
                now - continuousStartTime >= CONTINUOUS_SHAKE_MS
            ) {
                emit(GestureType.CONTINUOUS_SHAKE, now)
            }

            continuousStartTime = 0L
            return
        }

        if (continuousStartTime == 0L) {
            continuousStartTime = now
        }

        if (now - lastPeakTime < PEAK_DEBOUNCE_MS) {
            return
        }

        lastPeakTime = now

        peakTimes.addLast(now)

        while (
            peakTimes.isNotEmpty() &&
            now - peakTimes.first() > MULTI_SHAKE_WINDOW_MS
        ) {
            peakTimes.removeFirst()
        }

        if (magnitude >= sensitivity * STRONG_MULTIPLIER) {
            emit(GestureType.STRONG_SHAKE, now)
            peakTimes.clear()
            return
        }

        when (peakTimes.size) {
            1 -> emit(GestureType.SINGLE_SHAKE, now)

            2 -> emit(GestureType.DOUBLE_SHAKE, now)

            else -> {
                emit(GestureType.TRIPLE_SHAKE, now)
                peakTimes.clear()
            }
        }
    }

    private fun emit(
        gesture: GestureType,
        now: Long
    ) {
        if (now - lastGestureTime < cooldownMs) {
            return
        }

        lastGestureTime = now
        onGesture(gesture)
    }

    fun reset() {
        gravity.fill(0f)
        peakTimes.clear()
        lastPeakTime = 0L
        lastGestureTime = 0L
        continuousStartTime = 0L
    }

    companion object {
        private const val PEAK_DEBOUNCE_MS = 120L
        private const val MULTI_SHAKE_WINDOW_MS = 700L
        private const val CONTINUOUS_SHAKE_MS = 1_000L
        private const val STRONG_MULTIPLIER = 2.1f
    }
}