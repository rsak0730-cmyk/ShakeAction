package com.shakeaction.app.actions

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.VibrationEffect
import android.os.Vibrator
import com.shakeaction.app.data.AutomationEntity

class ActionExecutor(
    private val context: Context
) {
    fun execute(rule: AutomationEntity) {
        when (rule.action) {
            ACTION_TOGGLE_FLASHLIGHT -> toggleFlashlight()
            ACTION_FLASHLIGHT_ON -> setFlashlight(true)
            ACTION_FLASHLIGHT_OFF -> setFlashlight(false)
            ACTION_OPEN_APP -> openApp(rule.actionData)
            ACTION_VIBRATE -> vibrate()
            ACTION_VOLUME_UP -> adjustVolume(AudioManager.ADJUST_RAISE)
            ACTION_VOLUME_DOWN -> adjustVolume(AudioManager.ADJUST_LOWER)
            ACTION_HOME -> goHome()
            ACTION_OPEN_URL -> openUrl(rule.actionData)
        }

        if (
            rule.vibrationEnabled &&
            rule.action != ACTION_VIBRATE
        ) {
            vibrate()
        }
    }

    private fun cameraManager(): CameraManager? {
        return context.getSystemService(CameraManager::class.java)
    }

    private fun flashlightCameraId(): String? {
        val manager = cameraManager() ?: return null

        return try {
            manager.cameraIdList.firstOrNull { cameraId ->
                manager.getCameraCharacteristics(cameraId)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun setFlashlight(enabled: Boolean) {
        val manager = cameraManager() ?: return
        val cameraId = flashlightCameraId() ?: return

        try {
            manager.setTorchMode(cameraId, enabled)
            torchEnabled = enabled
        } catch (_: Exception) {
            // Some devices reject torch operations temporarily.
        }
    }

    private fun toggleFlashlight() {
        setFlashlight(!torchEnabled)
    }

    private fun openApp(packageName: String?) {
        if (packageName.isNullOrBlank()) {
            return
        }

        val intent = context.packageManager
            .getLaunchIntentForPackage(packageName)
            ?: return

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        runCatching {
            context.startActivity(intent)
        }
    }

    private fun openUrl(url: String?) {
        if (url.isNullOrBlank()) {
            return
        }

        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse(url)
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        runCatching {
            context.startActivity(intent)
        }
    }

    private fun vibrate() {
        val vibrator = context.getSystemService(Vibrator::class.java)
            ?: return

        if (vibrator.hasVibrator()) {
            vibrator.vibrate(
                VibrationEffect.createOneShot(
                    80L,
                    VibrationEffect.DEFAULT_AMPLITUDE
                )
            )
        }
    }

    private fun adjustVolume(direction: Int) {
        context.getSystemService(AudioManager::class.java)
            ?.adjustVolume(
                direction,
                AudioManager.FLAG_SHOW_UI
            )
    }

    private fun goHome() {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        context.startActivity(intent)
    }

    companion object {
        const val ACTION_TOGGLE_FLASHLIGHT = "TOGGLE_FLASHLIGHT"
        const val ACTION_FLASHLIGHT_ON = "FLASHLIGHT_ON"
        const val ACTION_FLASHLIGHT_OFF = "FLASHLIGHT_OFF"
        const val ACTION_OPEN_APP = "OPEN_APP"
        const val ACTION_VIBRATE = "VIBRATE"
        const val ACTION_VOLUME_UP = "VOLUME_UP"
        const val ACTION_VOLUME_DOWN = "VOLUME_DOWN"
        const val ACTION_HOME = "HOME"
        const val ACTION_OPEN_URL = "OPEN_URL"

        @Volatile
        var torchEnabled: Boolean = false
    }
}