package com.shakeaction.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val name: String,

    val gesture: String,

    val action: String,

    val actionData: String? = null,

    val enabled: Boolean = true,

    val sensitivity: Float = 2.7f,

    val cooldownMs: Long = 1_000L,

    val vibrationEnabled: Boolean = true
)