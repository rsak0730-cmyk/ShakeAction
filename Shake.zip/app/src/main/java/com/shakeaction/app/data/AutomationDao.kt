package com.shakeaction.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AutomationDao {

    @Query("SELECT * FROM automations ORDER BY id DESC")
    fun observeAll(): Flow<List<AutomationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(rule: AutomationEntity): Long

    @Update
    suspend fun update(rule: AutomationEntity)

    @Delete
    suspend fun delete(rule: AutomationEntity)

    @Query(
        "UPDATE automations SET enabled = :enabled WHERE id = :id"
    )
    suspend fun setEnabled(
        id: Long,
        enabled: Boolean
    )
}