package com.shakeaction.app.detector

enum class GestureType {
    SINGLE_SHAKE,
    DOUBLE_SHAKE,
    TRIPLE_SHAKE,
    STRONG_SHAKE,
    CONTINUOUS_SHAKE
}