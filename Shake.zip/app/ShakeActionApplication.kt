package com.shakeaction.app

import android.app.Application

class ShakeActionApplication : Application()